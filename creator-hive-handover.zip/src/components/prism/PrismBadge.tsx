"use client";

import type { PrismArchetypeName } from "@/lib/curatedTalent";
import { PRISM_ARCHETYPE_DESCRIPTIONS } from "@/lib/curatedTalent";
import { Tooltip } from "@/components/ui/tooltip";

type PrismBadgeProps = {
  archetypeName: PrismArchetypeName;
  size?: number;
};

export function PrismBadge({ archetypeName, size = 32 }: PrismBadgeProps) {
  const shortName = archetypeName.replace(/^The\s+/, "");
  const description = PRISM_ARCHETYPE_DESCRIPTIONS[archetypeName];
  const tooltipContent = description ? `${archetypeName} — ${description}` : archetypeName;

  return (
    <Tooltip content={tooltipContent}>
      <div
        className="inline-flex items-center justify-center rounded-full bg-white/10 ring-1 ring-white/20 text-[10px] font-medium text-white/90 truncate max-w-[72px] px-1.5 cursor-help"
        style={{ minWidth: size, height: size }}
      >
        {shortName}
      </div>
    </Tooltip>
  );
}
