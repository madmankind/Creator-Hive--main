/**
 * SEND REQUEST MODAL
 * Minimal modal for final request submission
 * ONLY asks for: companyName + contactEmail + optional phone/note
 * NO duplicate campaign description, NO trade license (moved to dashboard)
 */

"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Send } from "lucide-react";
import { cn } from "@/lib/utils";
import type { BriefLite, BookingRequestCreate } from "@/lib/schemas/booking";
import { BookingRequestCreateSchema } from "@/lib/schemas/booking";
import { OBJECTIVE_LABELS, MARKET_LABELS, LANGUAGE_LABELS, TIMELINE_LABELS, PRICING_TIER_LABELS } from "@/lib/schemas/booking";
import type { Talent } from "@/store/useCampaignPodStore";

type SendRequestModalProps = {
  open: boolean;
  onClose: () => void;
  brief: BriefLite;
  pod: Talent[];
  briefId?: string;
  podId?: string;
  onSubmit: (data: Omit<BookingRequestCreate, "briefId" | "podId">) => Promise<void>;
};

export function SendRequestModal({ open, onClose, brief, pod, briefId, podId, onSubmit }: SendRequestModalProps) {
  const [companyName, setCompanyName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [requestNote, setRequestNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    // Validate
    const result = BookingRequestCreateSchema.omit({ briefId: true, podId: true }).safeParse({
      companyName,
      contactEmail,
      contactPhone: contactPhone || undefined,
      requestNote: requestNote || undefined,
    });

    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach((issue) => {
        fieldErrors[issue.path[0] as string] = issue.message;
      });
      setErrors(fieldErrors);
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit(result.data);
      onClose();
    } catch (err) {
      setErrors({ submit: err instanceof Error ? err.message : "Failed to submit request" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={(e) => e.target === e.currentTarget && onClose()}
          >
            <div className="w-full max-w-lg max-h-[90vh] flex flex-col bg-[#0D1117] ring-1 ring-white/10 rounded-2xl overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-white/10 shrink-0">
                <div>
                  <h2 className="text-lg font-semibold text-white/90">Review & Send Request</h2>
                  <p className="text-sm text-white/60 mt-1">Confirm your booking details</p>
                </div>
                <button
                  onClick={onClose}
                  className="w-8 h-8 rounded-full bg-white/5 ring-1 ring-white/10 flex items-center justify-center hover:bg-white/10 transition text-white/60 hover:text-white/80"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {/* Brief Summary */}
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-white/90">Brief Summary</h3>
                  <div className="rounded-lg bg-white/5 ring-1 ring-white/10 p-4 space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-white/50">Objective:</span>
                      <span className="text-white/80">{OBJECTIVE_LABELS[brief.objective]}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-white/50">Outputs:</span>
                      <span className="text-white/80">{brief.outputs.join(", ")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-white/50">Platforms:</span>
                      <span className="text-white/80">{brief.platforms.join(", ")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-white/50">Market:</span>
                      <span className="text-white/80">{MARKET_LABELS[brief.market]}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-white/50">Language:</span>
                      <span className="text-white/80">{LANGUAGE_LABELS[brief.language]}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-white/50">Timeline:</span>
                      <span className="text-white/80">{TIMELINE_LABELS[brief.timeline]}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-white/50">Pricing Tier:</span>
                      <span className="text-white/80">{PRICING_TIER_LABELS[brief.pricingTier]}</span>
                    </div>
                  </div>
                </div>

                {/* Pod Summary */}
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-white/90">Selected Talent ({pod.length})</h3>
                  <div className="space-y-2">
                    {pod.map((talent) => (
                      <div key={talent.id} className="flex items-center gap-3 rounded-lg bg-white/5 ring-1 ring-white/10 p-3">
                        <div className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center text-sm font-medium text-white/80 shrink-0">
                          {talent.name.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-white/90 truncate">{talent.name}</p>
                          {talent.headline && (
                            <p className="text-xs text-white/60 truncate">{talent.headline}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Contact Form */}
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-white/90 mb-2 block">
                      Company Name <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      placeholder="Your company name"
                      className={cn(
                        "w-full rounded-lg bg-white/5 ring-1 px-3 py-2 text-sm text-white/90 placeholder:text-white/40 focus:outline-none focus:ring-white/30",
                        errors.companyName ? "ring-red-400" : "ring-white/10"
                      )}
                    />
                    {errors.companyName && <p className="text-xs text-red-400 mt-1">{errors.companyName}</p>}
                  </div>

                  <div>
                    <label className="text-sm font-medium text-white/90 mb-2 block">
                      Contact Email <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="email"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      placeholder="your@email.com"
                      className={cn(
                        "w-full rounded-lg bg-white/5 ring-1 px-3 py-2 text-sm text-white/90 placeholder:text-white/40 focus:outline-none focus:ring-white/30",
                        errors.contactEmail ? "ring-red-400" : "ring-white/10"
                      )}
                    />
                    {errors.contactEmail && <p className="text-xs text-red-400 mt-1">{errors.contactEmail}</p>}
                  </div>

                  <div>
                    <label className="text-sm font-medium text-white/90 mb-2 block">
                      Phone Number (optional)
                    </label>
                    <input
                      type="tel"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      placeholder="+971 50 123 4567"
                      className="w-full rounded-lg bg-white/5 ring-1 ring-white/10 px-3 py-2 text-sm text-white/90 placeholder:text-white/40 focus:outline-none focus:ring-white/30"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-white/90 mb-2 block">
                      Additional Note (optional)
                    </label>
                    <textarea
                      value={requestNote}
                      onChange={(e) => setRequestNote(e.target.value)}
                      placeholder="Any special requirements or questions?"
                      maxLength={500}
                      rows={3}
                      className={cn(
                        "w-full rounded-lg bg-white/5 ring-1 px-3 py-2 text-sm text-white/90 placeholder:text-white/40 focus:outline-none focus:ring-white/30 resize-none",
                        errors.requestNote ? "ring-red-400" : "ring-white/10"
                      )}
                    />
                    <div className="flex justify-between items-center mt-1">
                      <span className="text-[10px] text-white/40">{requestNote.length}/500</span>
                      {errors.requestNote && <p className="text-xs text-red-400">{errors.requestNote}</p>}
                    </div>
                  </div>

                  {errors.submit && (
                    <div className="rounded-lg bg-red-500/10 ring-1 ring-red-400/40 p-3">
                      <p className="text-sm text-red-400">{errors.submit}</p>
                    </div>
                  )}

                  {/* Submit Button */}
                  <div className="flex gap-3 pt-4">
                    <button
                      type="button"
                      onClick={onClose}
                      className="flex-1 rounded-full bg-white/5 text-white/70 hover:bg-white/10 ring-1 ring-white/10 px-4 py-2 text-sm font-medium transition"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={submitting}
                      className={cn(
                        "flex-1 rounded-full px-4 py-2 text-sm font-medium transition flex items-center justify-center gap-2",
                        submitting
                          ? "bg-white/5 text-white/30 cursor-not-allowed"
                          : "bg-white/10 text-white/90 hover:bg-white/15 ring-1 ring-white/20"
                      )}
                    >
                      {submitting ? (
                        "Sending..."
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          Send Request
                        </>
                      )}
                    </button>
                  </div>
                </form>

                {/* Info note */}
                <div className="rounded-lg bg-blue-500/10 ring-1 ring-blue-400/40 p-3">
                  <p className="text-xs text-blue-300">
                    <strong>Note:</strong> Trade license and additional documents can be uploaded later in your dashboard before contract signing.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
