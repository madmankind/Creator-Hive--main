/**
 * BRIEF-LITE WIZARD
 * 3-pane horizontal carousel inside the SAME frame as talent cards
 * NO resizing across steps, translateX transitions only
 * Frame: 420px × 285px (matches FRAME_TOKENS)
 */

"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import type { BriefLite, Objective, Timeline, PricingTier } from "@/lib/schemas/booking";
import {
  OBJECTIVE_LABELS,
  MARKET_LABELS,
  LANGUAGE_LABELS,
  TIMELINE_LABELS,
  PRICING_TIER_LABELS,
} from "@/lib/schemas/booking";

const OUTPUTS = ["UGC", "Edited video", "Photo shoot", "Social management", "Design", "Performance", "Web build"];
const PLATFORMS = ["TikTok", "Instagram", "YouTube", "Snapchat", "LinkedIn"];

type BriefLiteWizardProps = {
  initialRoles?: string[];
  onComplete: (brief: Omit<BriefLite, "id" | "createdAt" | "updatedAt">) => void;
  onCancel: () => void;
};

export function BriefLiteWizard({ initialRoles = [], onComplete, onCancel }: BriefLiteWizardProps) {
  const [step, setStep] = useState(1);
  const [direction, setDirection] = useState<1 | -1>(1);

  // Brief state
  const [objective, setObjective] = useState<Objective | null>(null);
  const [outputs, setOutputs] = useState<string[]>([]);
  const [platforms, setPlatforms] = useState<string[]>([]);
  const [markets, setMarkets] = useState<string[]>([]);
  const [languages, setLanguages] = useState<string[]>([]);
  const [keyMessage, setKeyMessage] = useState("");
  const [timeline, setTimeline] = useState<Timeline | null>(null);
  const [pricingTier, setPricingTier] = useState<PricingTier | null>(null);
  const [referenceLink, setReferenceLink] = useState("");

  const totalSteps = 3;

  const nextStep = () => {
    if (step < totalSteps && canProceed()) {
      setDirection(1);
      setStep(step + 1);
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setDirection(-1);
      setStep(step - 1);
    }
  };

  const canProceed = () => {
    if (step === 1) return objective && outputs.length > 0 && platforms.length > 0;
    if (step === 2) return markets.length > 0 && languages.length > 0;
    if (step === 3) return timeline && pricingTier;
    return false;
  };

  const handleComplete = () => {
    if (!canProceed()) return;

    onComplete({
      objective: objective!,
      outputs,
      platforms,
      markets,
      languages: languages as any, // Will be validated by schema
      keyMessaging: keyMessage.trim() || undefined,
      timeline: timeline!,
      pricingTier: pricingTier!,
      referenceUrl: referenceLink.trim() || undefined,
    });
  };

  const toggleArray = (arr: string[], setArr: (v: string[]) => void, value: string) => {
    setArr(arr.includes(value) ? arr.filter((x) => x !== value) : [...arr, value]);
  };

  const variants = {
    enter: (dir: number) => ({ x: dir > 0 ? "100%" : "-100%", opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (dir: number) => ({ x: dir > 0 ? "-100%" : "100%", opacity: 0 }),
  };

  return (
    <div
      className="relative w-[420px] max-w-[92vw] h-[285px] rounded-2xl bg-white/5 ring-1 ring-white/10 shadow-xl p-6 flex-shrink-0 overflow-hidden"
      style={{ perspective: "1000px" }}
    >
      {/* Fixed header */}
      <div className="absolute top-4 left-6 right-6 flex items-center justify-between z-20">
        <button onClick={onCancel} className="text-[11px] text-white/60 hover:text-white/90 transition">
          ← Back
        </button>
        <span className="text-[11px] font-medium uppercase tracking-wider text-white/50">
          {String(step).padStart(2, "0")} / {String(totalSteps).padStart(2, "0")}
        </span>
      </div>

      {/* Carousel container */}
      <div className="relative w-full h-full pt-8">
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={step}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ type: "tween", duration: 0.3 }}
            className="absolute inset-0 pt-8 pb-16 px-0 flex flex-col"
          >
            {/* Step content (scrollable if needed) */}
            <div className="flex-1 min-h-0 overflow-y-auto scrollbar-hide">
              {step === 1 && <Step1 {...{ objective, setObjective, outputs, setOutputs: (v) => setOutputs(v), platforms, setPlatforms: (v) => setPlatforms(v), toggleArray }} />}
              {step === 2 && <Step2 {...{ markets, setMarkets, languages, setLanguages, keyMessage, setKeyMessage, toggleArray }} />}
              {step === 3 && <Step3 {...{ timeline, setTimeline, pricingTier, setPricingTier, referenceLink, setReferenceLink }} />}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Fixed bottom navigation */}
        <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between gap-3">
          <button
            onClick={prevStep}
            disabled={step === 1}
            className={cn(
              "flex items-center gap-1 rounded-full px-4 py-2 text-xs font-medium transition",
              step === 1
                ? "bg-white/5 text-white/30 cursor-not-allowed"
                : "bg-white/10 text-white/80 hover:bg-white/15 ring-1 ring-white/10"
            )}
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            Back
          </button>

          {step < totalSteps ? (
            <button
              onClick={nextStep}
              disabled={!canProceed()}
              className={cn(
                "flex items-center gap-1 rounded-full px-4 py-2 text-xs font-medium transition",
                canProceed()
                  ? "bg-white/10 text-white/90 hover:bg-white/15 ring-1 ring-white/20"
                  : "bg-white/5 text-white/30 cursor-not-allowed"
              )}
            >
              Next
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={handleComplete}
              disabled={!canProceed()}
              className={cn(
                "rounded-full px-4 py-2 text-xs font-medium transition",
                canProceed()
                  ? "bg-white/10 text-white/90 hover:bg-white/15 ring-1 ring-white/20"
                  : "bg-white/5 text-white/30 cursor-not-allowed"
              )}
            >
              Continue
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================
// STEP COMPONENTS
// ============================================

function Step1({
  objective,
  setObjective,
  outputs,
  setOutputs,
  platforms,
  setPlatforms,
  toggleArray,
}: {
  objective: Objective | null;
  setObjective: (v: Objective) => void;
  outputs: string[];
  setOutputs: (v: string[]) => void;
  platforms: string[];
  setPlatforms: (v: string[]) => void;
  toggleArray: (arr: string[], setArr: (v: string[]) => void, value: string) => void;
}) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-medium text-white/90 mb-2">Objective</h3>
        <div className="flex flex-wrap gap-2">
          {(["AWARENESS", "GROWTH", "CONVERSIONS", "LAUNCH"] as Objective[]).map((obj) => (
            <button
              key={obj}
              onClick={() => setObjective(obj)}
              className={cn(
                "rounded-full px-3 py-1.5 text-[11px] font-medium transition",
                objective === obj
                  ? "bg-white/15 text-white ring-1 ring-white/30"
                  : "bg-white/5 text-white/60 hover:bg-white/10"
              )}
            >
              {OBJECTIVE_LABELS[obj]}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-sm font-medium text-white/90 mb-2">Outputs</h3>
        <div className="flex flex-wrap gap-2">
          {OUTPUTS.map((out) => (
            <button
              key={out}
              onClick={() => toggleArray(outputs, setOutputs, out)}
              className={cn(
                "rounded-full px-3 py-1.5 text-[11px] font-medium transition",
                outputs.includes(out)
                  ? "bg-white/15 text-white ring-1 ring-white/30"
                  : "bg-white/5 text-white/60 hover:bg-white/10"
              )}
            >
              {out}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-sm font-medium text-white/90 mb-2">Platforms</h3>
        <div className="flex flex-wrap gap-2">
          {PLATFORMS.map((plat) => (
            <button
              key={plat}
              onClick={() => toggleArray(platforms, setPlatforms, plat)}
              className={cn(
                "rounded-full px-3 py-1.5 text-[11px] font-medium transition",
                platforms.includes(plat)
                  ? "bg-white/15 text-white ring-1 ring-white/30"
                  : "bg-white/5 text-white/60 hover:bg-white/10"
              )}
            >
              {plat}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function Step2({
  markets,
  setMarkets,
  languages,
  setLanguages,
  keyMessage,
  setKeyMessage,
  toggleArray,
}: {
  markets: string[];
  setMarkets: (v: string[]) => void;
  languages: string[];
  setLanguages: (v: string[]) => void;
  keyMessage: string;
  setKeyMessage: (v: string) => void;
  toggleArray: (arr: string[], setArr: (v: string[]) => void, value: string) => void;
}) {
  const MARKET_OPTIONS = ["UAE", "KSA", "Egypt", "Qatar", "Kuwait", "Bahrain", "Oman", "Lebanon", "Jordan"];
  const LANGUAGE_OPTIONS = ["EN", "AR"];

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-medium text-white/90 mb-2">Markets (select one or more)</h3>
        <div className="flex flex-wrap gap-2">
          {MARKET_OPTIONS.map((mkt) => (
            <button
              key={mkt}
              onClick={() => toggleArray(markets, setMarkets, mkt)}
              className={cn(
                "rounded-full px-4 py-2 text-xs font-medium transition min-h-[36px]",
                markets.includes(mkt)
                  ? "bg-white/15 text-white ring-1 ring-white/30"
                  : "bg-white/5 text-white/60 hover:bg-white/10"
              )}
            >
              {MARKET_LABELS[mkt] || mkt}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-sm font-medium text-white/90 mb-2">Languages (select one or more)</h3>
        <div className="flex flex-wrap gap-2">
          {LANGUAGE_OPTIONS.map((lang) => (
            <button
              key={lang}
              onClick={() => toggleArray(languages, setLanguages, lang)}
              className={cn(
                "rounded-full px-4 py-2 text-xs font-medium transition min-h-[36px]",
                languages.includes(lang)
                  ? "bg-white/15 text-white ring-1 ring-white/30"
                  : "bg-white/5 text-white/60 hover:bg-white/10"
              )}
            >
              {LANGUAGE_LABELS[lang]}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="text-sm font-medium text-white/90 mb-2 block">Key messaging or Primary objective (optional)</label>
        <input
          type="text"
          value={keyMessage}
          onChange={(e) => setKeyMessage(e.target.value.slice(0, 120))}
          placeholder="What's the core message or primary goal?"
          maxLength={120}
          className="w-full rounded-lg bg-white/5 ring-1 ring-white/10 px-3 py-2 text-sm text-white/90 placeholder:text-white/40 focus:outline-none focus:ring-white/30"
        />
        <span className="text-[10px] text-white/40 mt-1 block">{keyMessage.length}/120</span>
      </div>
    </div>
  );
}

function Step3({
  timeline,
  setTimeline,
  pricingTier,
  setPricingTier,
  referenceLink,
  setReferenceLink,
}: {
  timeline: Timeline | null;
  setTimeline: (v: Timeline) => void;
  pricingTier: PricingTier | null;
  setPricingTier: (v: PricingTier) => void;
  referenceLink: string;
  setReferenceLink: (v: string) => void;
}) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-medium text-white/90 mb-2">Timeline</h3>
        <div className="flex flex-wrap gap-2">
          {(["ASAP", "THIS_MONTH", "NEXT_MONTH", "FLEXIBLE"] as Timeline[]).map((t) => (
            <button
              key={t}
              onClick={() => setTimeline(t)}
              className={cn(
                "rounded-full px-3 py-1.5 text-[11px] font-medium transition",
                timeline === t
                  ? "bg-white/15 text-white ring-1 ring-white/30"
                  : "bg-white/5 text-white/60 hover:bg-white/10"
              )}
            >
              {TIMELINE_LABELS[t]}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-sm font-medium text-white/90 mb-2">Pricing Tier</h3>
        <div className="flex gap-3">
          {(["PRO", "SIGNATURE"] as PricingTier[]).map((tier) => (
            <button
              key={tier}
              onClick={() => setPricingTier(tier)}
              className={cn(
                "flex-1 rounded-lg px-4 py-3 text-center transition",
                pricingTier === tier
                  ? "bg-white/15 text-white ring-2 ring-white/40"
                  : "bg-white/5 text-white/70 hover:bg-white/10 ring-1 ring-white/10"
              )}
            >
              <div className="text-sm font-medium">{PRICING_TIER_LABELS[tier]}</div>
              <div className="text-[10px] text-white/50 mt-1">
                {tier === "PRO" ? "Standard rates" : "Premium service"}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="text-sm font-medium text-white/90 mb-2 block">Reference Link (optional)</label>
        <input
          type="url"
          value={referenceLink}
          onChange={(e) => setReferenceLink(e.target.value)}
          placeholder="https://example.com/inspiration"
          className="w-full rounded-lg bg-white/5 ring-1 ring-white/10 px-3 py-2 text-sm text-white/90 placeholder:text-white/40 focus:outline-none focus:ring-white/30"
        />
      </div>
    </div>
  );
}
