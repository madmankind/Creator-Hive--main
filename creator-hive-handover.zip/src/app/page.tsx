// src/app/page.tsx
"use client";
import { useState, useEffect } from "react";
import { HeroBar } from "@/components/HeroBar";
import { TalentCarousel } from "@/components/marketing/TalentCarousel";
import { CampaignPodPanel } from "@/components/talent/CampaignPodPanel";
import { BriefLiteWizard } from "@/components/booking/BriefLiteWizard";
import { SendRequestSheet } from "@/components/booking/SendRequestSheet";
import { ClientAuthDialog } from "@/components/auth/ClientAuthDialog";
import { TalentOnboardingDialogFey } from "@/components/auth/TalentOnboardingDialogFey";
import { PodSetupOverlay } from "@/features/pod-setup/PodSetupOverlay";
import { curatedTalent } from "@/lib/curatedTalent";
import { computeMatchScore } from "@/lib/matching/match-score";
import type { BriefLite } from "@/lib/schemas/booking";
import { useCampaignPodStore, type Talent as PodTalent } from "@/store/useCampaignPodStore";
import { usePodConfigStore } from "@/store/usePodConfigStore";
import { useSession } from "next-auth/react";

export default function HomePage() {
  const [mode, setMode] = useState<'client' | 'talent'>('client');
  const [showTalentGallery, setShowTalentGallery] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [showBriefWizard, setShowBriefWizard] = useState(false);
  const [showSendModal, setShowSendModal] = useState(false);
  const [brief, setBrief] = useState<BriefLite | null>(null);
  const [bookingTalents, setBookingTalents] = useState<PodTalent[]>([]);
  const [clientAuthOpen, setClientAuthOpen] = useState(false);
  const [talentAuthOpen, setTalentAuthOpen] = useState(false);
  const [pendingDiscover, setPendingDiscover] = useState(false);
  
  // Landing pod state (localStorage-backed)
  const [selectedPodIds, setSelectedPodIds] = useState<string[]>([]);
  // Active talent for detail panel
  const [activeTalentId, setActiveTalentId] = useState<string | null>(null);
  
  const { selectedTalents } = useCampaignPodStore();
  const { openPodSetup } = usePodConfigStore();
  const { data: session } = useSession();
  const role = (session?.user as { role?: string | null } | undefined)?.role ?? null;
  const isClient = role === "AGENCY";

  // Load landing pod from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem("ch_landing_pod_ids");
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          setSelectedPodIds(parsed);
        }
      }
    } catch {
      // ignore parse errors
    }
  }, []);

  // Persist landing pod to localStorage
  useEffect(() => {
    if (selectedPodIds.length > 0) {
      localStorage.setItem("ch_landing_pod_ids", JSON.stringify(selectedPodIds));
    } else {
      localStorage.removeItem("ch_landing_pod_ids");
    }
  }, [selectedPodIds]);

  // Landing pod handlers
  const addToPod = (talentId: string) => {
    setSelectedPodIds((prev) => {
      if (prev.includes(talentId)) return prev;
      return [...prev, talentId];
    });
  };

  const removeFromPod = (talentId: string) => {
    setSelectedPodIds((prev) => prev.filter((id) => id !== talentId));
  };

  const clearPod = () => {
    setSelectedPodIds([]);
  };

  // Handle "Set up pod" click - check auth, then open brief wizard
  const handleSetUpPod = () => {
    if (selectedPodIds.length === 0) return; // Disabled if empty
    
    // Check if client session exists
    const hasSession = typeof window !== 'undefined' && localStorage.getItem('ch_client_session');
    
    if (!hasSession) {
      // Open auth dialog first
      setClientAuthOpen(true);
      setPendingDiscover(true); // Flag to open booking after auth
      return;
    }
    
    // Convert selectedPodIds to PodTalent[] and show brief section
    const podTalents: PodTalent[] = selectedPodIds
      .map((id) => {
        const talent = curatedTalent.find((t) => t.id === id);
        if (!talent) return null;
        return {
          id: talent.id,
          name: talent.name,
          headline: talent.displayTitle,
          avatarUrl: talent.avatarUrl,
          roles: talent.roleTags,
          platforms: talent.platformTags,
          availabilityTags: talent.availability,
          bio: talent.shortBio,
        };
      })
      .filter((t): t is PodTalent => t !== null);
    
    setBookingTalents(podTalents);
    setShowBriefWizard(true);
    
    // Scroll to brief section smoothly
    setTimeout(() => {
      document.getElementById("brief-section")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 100);
  };

  const handleBriefComplete = (briefData: Omit<Brief, "id" | "createdAt" | "updatedAt">) => {
    // Create brief with mock ID (in real flow, this would be saved to DB)
    const newBrief: Brief = {
      id: `brief_${Date.now()}`,
      ...briefData,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setBrief(newBrief);
    setShowBriefWizard(false);
    setShowSendModal(true);
  };

  const handleSendRequest = async (data: any) => {
    try {
      // TODO: Implement actual API call
      console.log("Booking request:", { ...data, briefId: brief?.id });
      alert(`Request submitted!\nCompany: ${data.companyName}\nEmail: ${data.contactEmail}`);
      setShowSendModal(false);
      clearPod(); // Clear pod after successful submission
    } catch (error) {
      console.error("Failed to submit request:", error);
    }
  };

  useEffect(() => {
    if (isClient && pendingDiscover) {
      setShowTalentGallery(true);
      setTimeout(() => {
        document.getElementById("talent-gallery")?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 150);
      setPendingDiscover(false);
    }
  }, [isClient, pendingDiscover]);

  return (
    <main className="min-h-screen bg-[#0B0F14] text-slate-200">
      {/* Subtle vertical glow like Fey */}
      <div className="pointer-events-none fixed inset-0 flex items-start justify-center">
        <div className="mt-8 h-[40vh] w-[60vw] max-w-[900px] blur-3xl opacity-[0.16] bg-gradient-to-b from-white/25 via-white/10 to-transparent rounded-full"></div>
      </div>

      {/* Centered content container */}
      <div className="relative flex items-center justify-center min-h-screen px-6">
        <div className="w-full max-w-[1100px]">
          {/* Header - Perfectly centered */}
          <div className="text-center space-y-6 mb-12">
            <h1 className="text-[32px] md:text-[40px] font-semibold tracking-[-0.02em] text-white/90">
              Welcome to Creator Hive
            </h1>

            {/* Toggle */}
            <div className="inline-flex items-center gap-1 rounded-full bg-white/5 p-1 ring-1 ring-white/10">
              <button 
                onClick={() => setMode('client')}
                className={`px-3.5 py-1.5 rounded-full text-[12px] font-medium transition ${
                  mode === 'client' 
                    ? 'bg-white/10 text-white ring-1 ring-white/15' 
                    : 'text-white/60 hover:text-white'
                }`}
              >
                Client
              </button>
              <button 
                onClick={() => setMode('talent')}
                className={`px-3.5 py-1.5 rounded-full text-[12px] font-medium transition ${
                  mode === 'talent' 
                    ? 'bg-white/10 text-white ring-1 ring-white/15' 
                    : 'text-white/60 hover:text-white'
                }`}
              >
                Talent
              </button>
            </div>

            <p className="text-[14px] text-white/60">
              {mode === 'client' ? 'Book Top 1% talent seamlessly' : 'Join the Hive to showcase your work and get discovered.'}
            </p>
            {mode === 'client' && (
              <p className="text-[13px] text-white/50 mt-2">
                Describe your campaign and choose the roles you need – we&apos;ll surface curated talent that fits.
              </p>
            )}
          </div>

          {/* Hero Bar - Centered */}
          <div className="flex justify-center">
            <div className="w-full max-w-[860px]">
              <HeroBar
                mode={mode}
                onQueryChange={(q) => setSearchQuery(q)}
                onRolesChange={(roles) => setSelectedRoles(roles)}
                onDiscover={() => {
                  if (!session?.user) {
                    if (mode === 'client') {
                      setPendingDiscover(true);
                      setClientAuthOpen(true);
                    } else {
                      setTalentAuthOpen(true);
                    }
                    return;
                  }
                  if (mode === 'client' && !isClient) {
                    setPendingDiscover(true);
                    setClientAuthOpen(true);
                    return;
                  }
                  // Proceed to gallery
                  setShowTalentGallery(true);
                  setTimeout(() => {
                    document.getElementById("talent-gallery")?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }, 100);
                }}
                onOpenBriefBuilder={() => {
                  if (mode === 'client' && !isClient) {
                    setClientAuthOpen(true);
                    return;
                  }
                  // Show brief section with empty talents for brief builder
                  setBookingTalents([]);
                  setShowBriefWizard(true);
                  setTimeout(() => {
                    document.getElementById("brief-section")?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }, 100);
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Talent Gallery Section */}
      {mode === 'client' && showTalentGallery && (
        <section id="talent-gallery" className="mt-20 md:mt-28">
          <TalentCarousel 
            talents={curatedTalent} 
            query={searchQuery} 
            selectedRoles={selectedRoles}
            selectedPodIds={selectedPodIds}
            onAddToPod={addToPod}
            onBook={(talent) => {
              // Convert to PodTalent and scroll to brief section
              // If pod is empty, add talent then show brief; otherwise just show with this talent
              const curated = curatedTalent.find(t => t.id === talent.id);
              if (curated) {
                const podTalent: PodTalent = {
                  id: talent.id,
                  name: talent.name,
                  headline: talent.headline || curated.displayTitle,
                  avatarUrl: talent.avatarUrl,
                  roles: talent.roles,
                  platforms: talent.platforms,
                  availabilityTags: talent.availabilityTags,
                  bio: talent.bio,
                };
                
                // If pod is empty, add this talent first
                if (selectedPodIds.length === 0) {
                  addToPod(podTalent.id);
                }
                
                setBookingTalents([podTalent]);
                setShowBriefWizard(true);
                setTimeout(() => {
                  document.getElementById("brief-section")?.scrollIntoView({ behavior: "smooth", block: "start" });
                }, 100);
              }
            }}
            onTalentClick={(talentId) => {
              // Find the talent and scroll to brief section
              const talent = curatedTalent.find(t => t.id === talentId);
              if (talent) {
                const podTalent: PodTalent = {
                  id: talent.id,
                  name: talent.name,
                  headline: talent.displayTitle,
                  avatarUrl: talent.avatarUrl,
                  roles: talent.roleTags,
                  platforms: talent.platformTags,
                  availabilityTags: talent.availability,
                  bio: talent.shortBio,
                };
                setBookingTalents([podTalent]);
                setShowBriefWizard(true);
                setTimeout(() => {
                  document.getElementById("brief-section")?.scrollIntoView({ behavior: "smooth", block: "start" });
                }, 100);
              }
            }}
          />
        </section>
      )}

      {/* Campaign Pod Panel */}
      {mode === 'client' && (
        <CampaignPodPanel
          selectedPodIds={selectedPodIds}
          onRemove={removeFromPod}
          onClear={clearPod}
          onOpenBrief={handleSetUpPod}
          onOpenProfile={(talentId) => {
            // Scroll to talent or expand detail view
            const talent = curatedTalent.find(t => t.id === talentId);
            if (talent) {
              document.getElementById(`talent-${talentId}`)?.scrollIntoView({ behavior: 'smooth' });
            }
          }}
        />
      )}

      {/* Pod Setup Overlay */}
      <PodSetupOverlay />

      {/* Brief Section - Embedded (not modal) */}
      {showBriefWizard && (
        <section id="brief-section" className="mt-20 md:mt-28 px-4">
          <div className="max-w-[1680px] mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl font-semibold text-white mb-2">Share your brief</h2>
              <p className="text-white/60">Tell us about your campaign so we can match you with the perfect talent</p>
            </div>
            
            {/* Wide Brief Card - ~3-4 talent cards width */}
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl ring-1 ring-white/10 p-8">
              <BriefLiteWizard
                initialRoles={selectedRoles}
                onComplete={handleBriefComplete}
                onCancel={() => {
                  setShowBriefWizard(false);
                  setBookingTalents([]);
                }}
              />
            </div>
          </div>
        </section>
      )}

      {/* Send Request Sheet - OS-style right-side panel */}
      {showSendModal && brief && (
        <SendRequestSheet
          open={showSendModal}
          onClose={() => {
            setShowSendModal(false);
            setBrief(null);
          }}
          brief={brief}
          pod={bookingTalents}
          onSubmit={handleSendRequest}
        />
      )}

      {/* Client Auth Dialog */}
      <ClientAuthDialog
        open={clientAuthOpen}
        onClose={() => {
          setClientAuthOpen(false);
          setPendingDiscover(false);
        }}
        onSuccess={() => {
          if (pendingDiscover) {
            // Check if we should open booking modal (after "Set up pod" auth)
            const hasPodIds = selectedPodIds.length > 0;
            if (hasPodIds) {
              // Open booking modal with selected talents
              const podTalents: PodTalent[] = selectedPodIds
                .map((id) => {
                  const talent = curatedTalent.find((t) => t.id === id);
                  if (!talent) return null;
                  return {
                    id: talent.id,
                    name: talent.name,
                    headline: talent.displayTitle,
                    avatarUrl: talent.avatarUrl,
                    roles: talent.roleTags,
                    platforms: talent.platformTags,
                    availabilityTags: talent.availability,
                    bio: talent.shortBio,
                  };
                })
                .filter((t): t is PodTalent => t !== null);
              setBookingTalents(podTalents);
              setShowBriefWizard(true);
              setPendingDiscover(false);
            } else {
              // Original behavior: scroll to gallery
              setTimeout(() => {
                setShowTalentGallery(true);
                document.getElementById("talent-gallery")?.scrollIntoView({ behavior: "smooth", block: "start" });
              }, 200);
              setPendingDiscover(false);
            }
          }
        }}
      />

      {/* Talent Onboarding Dialog */}
      <TalentOnboardingDialogFey
        open={talentAuthOpen}
        onClose={() => setTalentAuthOpen(false)}
        onSuccess={() => {
          // Talent onboarding complete
        }}
      />

      {/* Footer Disclaimer */}
      <footer className="mt-16 border-t border-white/10 pt-4 pb-6 text-center">
        <p className="text-[11px] text-white/45">
          Creator Hive is human-first. Please clearly label any AI-generated media.
        </p>
      </footer>
    </main>
  );
}
